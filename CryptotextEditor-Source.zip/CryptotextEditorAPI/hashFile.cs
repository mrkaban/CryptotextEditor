﻿using System;
using System.IO;
using System.Security.Cryptography;

namespace CryptotextEditorAPI
{
    public class hashFile
    {
        public static string md5(string filePath)
        {
            FileStream FileCheck;
            MD5 md5;
            byte[] md5Hash;
            string HashValue;

            try
            {
                FileCheck = System.IO.File.OpenRead(filePath);
                md5 = new MD5CryptoServiceProvider();
                md5Hash = md5.ComputeHash(FileCheck);
                FileCheck.Close();
                HashValue = BitConverter.ToString(md5Hash).Replace("-", "").ToLower();
                return HashValue;
            }
            catch
            {
                return null;
            }
        }

        public static string Sha1(string filePath)
        {
            FileStream FileCheck;
            SHA1CryptoServiceProvider SHA1;
            byte[] Hash;
            string HashValue;

            try
            {
                FileCheck = System.IO.File.OpenRead(filePath);
                SHA1 = new SHA1CryptoServiceProvider();
                Hash = SHA1.ComputeHash(FileCheck);
                FileCheck.Close();
                HashValue = BitConverter.ToString(Hash).Replace("-", "").ToLower();
                return HashValue;
            }
            catch
            {
                return null;
            }
        }

        public static string Sha256(string filePath)
        {
            FileStream FileCheck;
            SHA256CryptoServiceProvider SHA256;
            byte[] Hash;
            string HashValue;

            try
            {
                FileCheck = System.IO.File.OpenRead(filePath);
                SHA256 = new SHA256CryptoServiceProvider();
                Hash = SHA256.ComputeHash(FileCheck);
                FileCheck.Close();
                HashValue = BitConverter.ToString(Hash).Replace("-", "").ToLower();
                return HashValue;
            }
            catch
            {
                return null;
            }
        }

        public static string Sha384(string filePath)
        {
            FileStream FileCheck;
            SHA384CryptoServiceProvider SHA384;
            byte[] Hash;
            string HashValue;

            try
            {
                FileCheck = System.IO.File.OpenRead(filePath);
                SHA384 = new SHA384CryptoServiceProvider();
                Hash = SHA384.ComputeHash(FileCheck);
                FileCheck.Close();
                HashValue = BitConverter.ToString(Hash).Replace("-", "").ToLower();
                return HashValue;
            }
            catch
            {
                return null;
            }
        }

        public static string Sha512(string filePath)
        {
            FileStream FileCheck;
            SHA512CryptoServiceProvider SHA512;
            byte[] Hash;
            string HashValue;

            try
            {
                FileCheck = System.IO.File.OpenRead(filePath);
                SHA512 = new SHA512CryptoServiceProvider();
                Hash = SHA512.ComputeHash(FileCheck);
                FileCheck.Close();
                HashValue = BitConverter.ToString(Hash).Replace("-", "").ToLower();
                return HashValue;
            }
            catch
            {
                return null;
            }
        }

        public static string RIPEMD160(string filePath)
        {
            FileStream FileCheck;
            RIPEMD160 ripemp;
            byte[] Hash;
            string HashValue;

            try
            {
                FileCheck = System.IO.File.OpenRead(filePath);
                ripemp = new RIPEMD160Managed();
                Hash = ripemp.ComputeHash(FileCheck);
                FileCheck.Close();
                HashValue = BitConverter.ToString(Hash).Replace("-", "").ToLower();
                return HashValue;
            }
            catch
            {
                return null;
            }
        }
    }
}
