﻿using System;
using System.Text;
using System.Security.Cryptography;

namespace CryptotextEditorAPI
{
    public static class hashString
    {
        public static string md5(string sText)
        {
            byte[] textBytes;
            MD5CryptoServiceProvider cryptHandler;
            byte[] hash;
            string ret = "";

            try
            {
                textBytes = System.Text.Encoding.Default.GetBytes(sText);
                cryptHandler = new MD5CryptoServiceProvider();
                hash = cryptHandler.ComputeHash(textBytes);

                foreach (byte a in hash)
                {
                    if (a < 16)
                    {
                        ret += "0" + a.ToString("x");
                    }
                    else
                    {
                        ret += a.ToString("x");
                    }
                }
                return ret;
            }
            catch
            {
                throw;
            }
        }

        public static string Sha1(string sText)
        {
            SHA1 sha1;
            byte[] data;
            byte[] hash;
            string hexaHash = "";

            try
            {
                sha1 = new SHA1CryptoServiceProvider();
                data = Encoding.Default.GetBytes(sText);
                hash = sha1.ComputeHash(data);

                foreach (byte b in hash)
                {
                    hexaHash += String.Format("{0:x2}", b);
                }
                return hexaHash;
            }
            catch
            {
                return sText;
            }
        }

        public static string Sha256(string sText)
        {
            SHA256 sha256;
            byte[] data;
            byte[] hash;
            string hexaHash = "";

            try
            {
                sha256 = new SHA256CryptoServiceProvider();
                data = Encoding.Default.GetBytes(sText);
                hash = sha256.ComputeHash(data);

                foreach (byte b in hash)
                {
                    hexaHash += String.Format("{0:x2}", b);
                }
                return hexaHash;
            }
            catch
            {
                return sText;
            }
        }

        public static string Sha384(string sText)
        {
            SHA384 sha384;
            byte[] data;
            byte[] hash;
            string hexaHash = "";

            try
            {
                sha384 = new SHA384CryptoServiceProvider();
                data = Encoding.Default.GetBytes(sText);
                hash = sha384.ComputeHash(data);

                foreach (byte b in hash)
                {
                    hexaHash += String.Format("{0:x2}", b);
                }
                return hexaHash;
            }
            catch
            {
                return sText;
            }
        }

        public static string Sha512(string sText)
        {
            SHA512 sha512;
            byte[] data;
            byte[] hash;
            string hexaHash = "";

            try
            {
                sha512 = new SHA512CryptoServiceProvider();
                data = Encoding.Default.GetBytes(sText);
                hash = sha512.ComputeHash(data);

                foreach (byte b in hash)
                {
                    hexaHash += String.Format("{0:x2}", b);
                }
                return hexaHash;
            }
            catch
            {
                return sText;
            }
        }

        public static string RIPEMD160(string sText)
        {
            HMACRIPEMD160 ripemd;
            byte[] data;
            byte[] hash;
            string hexaHash = "";

            try
            {
                ripemd = new HMACRIPEMD160();
                data = Encoding.Default.GetBytes(sText);
                hash = ripemd.ComputeHash(data);

                foreach (byte b in hash)
                {
                    hexaHash += String.Format("{0:x2}", b);
                }
                return hexaHash;
            }
            catch
            {
                return sText;
            }
        }
    }
}
