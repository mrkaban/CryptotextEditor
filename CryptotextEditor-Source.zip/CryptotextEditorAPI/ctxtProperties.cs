﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace CryptotextEditorAPI
{
    public static class ctxtProperties
    {
        internal static readonly Version verSupported = new Version(2, 2);

        /// <summary>
        /// Read the version of an existing CTXT file.
        /// </summary>
        /// <returns>Returns the CTXT version with major and minor version.</returns>
        internal static Version GetVersion(string filePath)
        {
            Version v;
            XmlDocument xFile = new XmlDocument();
            XmlNode nodeHead;
            string[] sVersion = new string[2];

            xFile.Load(filePath);
            nodeHead = xFile.GetElementsByTagName("ctxt").Item(0);
            sVersion = (nodeHead.Attributes.GetNamedItem("version").InnerText).Split('.');
            v = new Version(Convert.ToInt16(sVersion[0]), Convert.ToInt16(sVersion[1]));

            return v;
        }

        /// <summary>
        /// Checks that the file is a real CTXT file.
        /// </summary>
        /// <param name="filePath">Filepath as string.</param>
        /// <returns>true or false</returns>
        public static bool DocIsCTXT(string filePath)
        {
            XmlDocument xFile;
            XmlElement ctxte;
            string realCtxt;

            try
            {
                xFile = new XmlDocument();
                xFile.Load(filePath);
                ctxte = xFile.DocumentElement;
                realCtxt = ctxte.Name;

                if (realCtxt == "ctxt")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Checks that the CTXT file use RTF to save the text.
        /// </summary>
        /// <param name="filePath">Filepath as string.</param>
        /// <returns>true or false</returns>
        public static bool DocIsRTF(string filePath)
        {
            XmlDocument xFile;
            XmlNode nodeHead;
            string rtf;

            try
            {
                xFile = new XmlDocument();
                xFile.Load(filePath);
                nodeHead = xFile.GetElementsByTagName("head").Item(0);
                rtf = (nodeHead.Attributes.GetNamedItem("rtf").InnerText).ToLower();

                if (rtf == "true")
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                return false;
            }
        }
    }
}
