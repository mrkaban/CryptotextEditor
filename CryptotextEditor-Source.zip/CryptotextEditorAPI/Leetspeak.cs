﻿using System.Collections.Generic;
using System.Text;

namespace CryptotextEditorAPI
{
	/// <summary>
	/// This is the class for the Leetspeak encryption
	/// </summary>
    public class Leetspeak
    {
        private Dictionary<char, char> charDict = new Dictionary<char, char>();

        /// <summary>
        /// Creat a new instance.
        /// </summary>
        public Leetspeak()
        {
            charDict.Add('a', '4');
            charDict.Add('4', 'a');

            charDict.Add('b', '8');
            charDict.Add('8', 'b');

            charDict.Add('e', '3');
            charDict.Add('3', 'e');

            charDict.Add('g', '9');
            charDict.Add('9', 'g');

            charDict.Add('i', '!');
            charDict.Add('!', 'i');

            charDict.Add('l', '1');
            charDict.Add('1', 'l');

            charDict.Add('o', '0');
            charDict.Add('0', 'o');

            charDict.Add('r', '2');
            charDict.Add('2', 'r');

            charDict.Add('s', '5');
            charDict.Add('5', 's');

            charDict.Add('t', '7');
            charDict.Add('7', 't');
        }

        public string Convert(string sText)
        {
            StringBuilder sBuilder;

            try
            {
                sBuilder = new StringBuilder();

                foreach (char c in sText)
                {
                    char c2 = c;
                    if (charDict.ContainsKey(c))
                    {
                        c2 = charDict[c];
                    }

                    sBuilder.Append(c2);
                }

                return sBuilder.ToString();
            }
            catch
            {
                return sText;
            }
        }
    }
}
