﻿using System;
using System.IO;
using System.Text;
using System.Security.Cryptography;

namespace CryptotextEditorAPI
{
    public static class encryptions
    {

        /// <summary>
        /// Encrypt any string from Base64.
        /// It uses the UTF-8 encoding.
        /// </summary>
        /// <param name="sText"></param>
        /// <returns></returns>
        public static string ToBase64(string sText)
        {
            byte[] toEncodeAsBytes;
            try
            {
                toEncodeAsBytes = UnicodeEncoding.UTF8.GetBytes(sText);
                return Convert.ToBase64String(toEncodeAsBytes);
            }
            catch
            {
                return sText;
            }
        }

        /// <summary>
        /// Decrypt any string from Base64.
        /// </summary>
        public static string FromBase64(string sText)
        {
            byte[] encodedData;
            try
            {
                sText = sText.Replace(" ", "");
                encodedData = Convert.FromBase64String(sText);
                return UnicodeEncoding.UTF8.GetString(encodedData);
            }
            catch
            {
                return sText;
            }
        }

        /// <summary>
        /// Encrypt and decrypt any string with Rot13.
        /// </summary>
        public static string ToRot13(string sText)
        {
            byte[] textBytes;
            int[] textInts;

            try
            {
                textBytes = System.Text.Encoding.UTF8.GetBytes(sText);
                textInts = new int[textBytes.Length];

                for (int i = 0; i < textBytes.Length; i++)
                {
                    textInts[i] = Convert.ToInt32(textBytes[i]);

                    if (textInts[i] >= 65 & textInts[i] <= 90)
                    {
                        textInts[i] = (textInts[i] + 13);
                        if (textInts[i] > 90)
                        {
                            textInts[i] = (textInts[i] - 26);
                        }
                    }

                    if (textInts[i] >= 97 & textInts[i] <= 122)
                    {
                        textInts[i] = (textInts[i] + 13);
                        if (textInts[i] > 122)
                        {
                            textInts[i] = (textInts[i] - 26);
                        }
                    }
                }

                for (int i = 0; i < textBytes.Length; i++)
                {
                    textBytes[i] = Convert.ToByte(textInts[i]);
                }

                return System.Text.UnicodeEncoding.UTF8.GetString(textBytes);
            }
            catch
            {
                return sText;
            }
        }

        /// <summary>
        /// Encypt any string to Bytes.
        /// </summary>
        public static string ToArcsByte(string sText)
        {
            byte[] textBytes;
            string bytestr = "";

            try
            {
                textBytes = System.Text.Encoding.UTF8.GetBytes(sText);
                foreach (int b in textBytes)
                {
                    if (b < 10)
                    {
                        bytestr += "00" + b.ToString();
                    }
                    else if (b < 100 & b >= 10)
                    {
                        bytestr += "0" + b.ToString();
                    }
                    else
                    {
                        bytestr += b.ToString();
                    }
                }
                return bytestr;
            }
            catch
            {
                return sText;
            }
        }

        /// <summary>
        /// Decrypt any string from Bytes.
        /// </summary>
        public static string FromArcsByte(string sText)
        {
            string[] xStr;
            int[] xInt;
            byte[] xByte;
            sText = sText.Replace(" ", "");

            try
            {
                xStr = SplitToThree(sText);
                xInt = new int[xStr.Length];
                xByte = new byte[xStr.Length];

                for (int i = 0; i < xStr.Length; i++)
                {
                    xInt[i] = Convert.ToInt32(xStr[i]);
                    xByte[i] = Convert.ToByte(xInt[i]);
                }
                return System.Text.UnicodeEncoding.UTF8.GetString(xByte);
            }
            catch
            {
                return sText;
            }
        }

        private static string[] SplitToThree(string input)
        {
            if (input.Length % 3 != 0) return null;

            int len = input.Length / 3;
            string[] ret = new string[len];

            for (int i = 0; i < len; i++)
            {
                ret[i] = input.Substring(i * 3, 3);
            }
            return ret;
        }

        /// <summary>
        /// Encrypt any string with the AES 256 bit encryption.
        /// This uses the UTF-8 encoding.
        /// </summary>
        /// <param name="originalstring">
        /// The string you want to encrypt.
        /// </param>
        /// <param name="passphrase">
        /// This is the password that will be used to encrypt the text.
        /// </param>
        public static string AESencrypt(string originalstring, string passphrase)
        {
            byte[] initVectorBytes;
            byte[] saltValueBytes;
            byte[] origTextBytes;

            try
            {
                passphrase = hashString.Sha512(passphrase);
                initVectorBytes = Encoding.UTF8.GetBytes("%1B2FdD4e5Fjh9H8");
                saltValueBytes = Encoding.UTF8.GetBytes(hashString.md5(passphrase));
                origTextBytes = Encoding.UTF8.GetBytes(originalstring);

                PasswordDeriveBytes pwd = new PasswordDeriveBytes(passphrase, saltValueBytes, "SHA512", 1);
                byte[] keyBytes = pwd.GetBytes(256 / 8);
                RijndaelManaged symKey = new RijndaelManaged();

                symKey.Padding = PaddingMode.ISO10126;
                symKey.Mode = CipherMode.CBC;

                ICryptoTransform encryptor = symKey.CreateEncryptor(keyBytes, initVectorBytes);
                MemoryStream memstr = new MemoryStream();
                CryptoStream crypstr = new CryptoStream(memstr, encryptor, CryptoStreamMode.Write);

                crypstr.Write(origTextBytes, 0, origTextBytes.Length);
                crypstr.FlushFinalBlock();

                byte[] cipherTextBytes = memstr.ToArray();

                memstr.Close();
                crypstr.Close();

                return Convert.ToBase64String(cipherTextBytes);
            }
            catch
            {
                return originalstring;
            }
        }

        /// <summary>
        /// Decrypt any string with the AES 256 bit encryption.
        /// This uses the UTF-8 encoding.
        /// </summary>
        /// <param name="encryptedstring">
        /// Input here the string which is encrypted with the AESencrypt() method.
        /// </param>
        /// <param name="passphrase">
        /// This is the password that will be used to decrypt the text.
        /// </param>
        public static string AESdecrypt(string encryptedstring, string passphrase, string hashAlgorithm = "SHA512")
        {
            byte[] initVectorBytes;
            byte[] saltValueBytes;
            byte[] encryptedStringBytes;
            int times = 1;

            try
            {
                initVectorBytes = Encoding.UTF8.GetBytes("%1B2FdD4e5Fjh9H8");
                encryptedStringBytes = Convert.FromBase64String(encryptedstring);

                if (hashAlgorithm == "SHA512")
                {
                    passphrase = hashString.Sha512(passphrase);
                    saltValueBytes = Encoding.UTF8.GetBytes(hashString.md5(passphrase));
                    times = 1;
                }
                else
                {
                    saltValueBytes = Encoding.UTF8.GetBytes("CryptotextEditorAES256");
                    times = 2;
                }

                PasswordDeriveBytes pwd = new PasswordDeriveBytes(passphrase, saltValueBytes, hashAlgorithm, times);
                byte[] keyBytes = pwd.GetBytes(256 / 8);
                RijndaelManaged symKey = new RijndaelManaged();

                symKey.Padding = PaddingMode.ISO10126;
                symKey.Mode = CipherMode.CBC;

                ICryptoTransform decryptor = symKey.CreateDecryptor(keyBytes, initVectorBytes);
                MemoryStream memstr = new MemoryStream(encryptedStringBytes);
                CryptoStream crypstr = new CryptoStream(memstr, decryptor, CryptoStreamMode.Read);

                byte[] origTextBytes = new byte[encryptedstring.Length];
                int decryptedByteCount = crypstr.Read(origTextBytes, 0, origTextBytes.Length);

                memstr.Close();
                crypstr.Close();

                return Encoding.UTF8.GetString(origTextBytes, 0, decryptedByteCount);
            }
            catch
            {
                return encryptedstring;
            }
        }
    }
}