﻿using System;
using System.Text;
using System.Windows.Forms;
using System.Xml;

namespace CryptotextEditorAPI
{
	/// <summary>
	/// This is the class which is needed to create the ctxt file.
	/// </summary>5
    public class ctxtFile
    {
        /// <summary>
        /// Returns which version is supported by this API.
        /// </summary>
        public readonly Version verSupported = new Version(2, 2);
        private static readonly string v21pass = "CTXTAES256";

        /// <summary>
        /// Get or set the password for the ctxt file.
        /// </summary>
        public string PassPhrase;

        /// <summary>
        /// Get or set the filepath for the ctxt file.
        /// </summary>
        public string filePath;

        /// <summary>
        /// Get or set the config for RTF.
        /// </summary>
        public bool SaveWithRTF;

        /// <summary>
        /// Get or set if the password should be saved or not.
        /// </summary>
        public bool SavePassString;

        /// <summary>
        /// Get or set the encryption for the CTXT file.
        /// </summary>
        public Encryption encName;

        /// <summary>
        /// Get the version of the CTXT file.
        /// </summary>
        public Version docVersion;

        /// <summary>
        /// Creates a new instance.
        /// </summary>
        /// <param name="filePath">The filepath to file.</param>
        public ctxtFile(string filePath)
        {
            this.filePath = filePath;
            this.encName = Encryption.TimeAES;
            this.SaveWithRTF = true;
            this.PassPhrase = "";
            this.SavePassString = true;

            if(System.IO.File.Exists(filePath) == true & ctxtProperties.DocIsCTXT(filePath) == true)
            {
                this.encName = GetEncryption();
                this.SaveWithRTF = ctxtProperties.DocIsRTF(filePath);
                this.PassPhrase = GetPassphrase(filePath);
                this.docVersion = ctxtProperties.GetVersion(filePath);
            }
        }

        /// <summary>
        /// The kind of encryption for CTXT files.
        /// </summary>
        public enum Encryption
        {
            CryptotextEditorAES,
            TimeAES,
            Base64
        }

        /// <summary>
        /// Reads the file from the variable 'filePath'.
        /// </summary>
        /// <returns>Returns the text from the file as an string or returns an error.</returns>
        public string ReadFile()
        {
            DialogResult MsgResult;

            if (docVersion.Minor <= verSupported.Minor)
            {
                return ReadFileText();
            }
            else if (docVersion.Major == verSupported.Major)
            {
                MsgResult = MessageBox.Show("This version is perhaps not compatible with this API.\nDo you want try to open it?", "Wrong version!", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (MsgResult == DialogResult.Yes)
                {
                    return ReadFileText();
                }
                else
                {
                    return null;
                }
            }
            else
            {
                MessageBox.Show("This version of the CTXT file is not supported!", "Wrong version!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        private string ReadFileText()
        {
            XmlDocument xFile;
            XmlNode nodeText;
            string docText;
            string hashAlgorithm = "SHA512";
            string tmpPwd;

            try
            {
                xFile = new XmlDocument();
                xFile.Load(this.filePath);
                nodeText = xFile.GetElementsByTagName("text").Item(0);

                if (docVersion < verSupported)
                {
                    hashAlgorithm = "MD5";
                }

                tmpPwd = GetPassphrase(this.filePath);

                if (GetEncryption() == Encryption.Base64)
                {
                    docText = encryptions.FromBase64(nodeText.InnerText);
                }
                else if (tmpPwd.Length > 1)
                {
                    docText = encryptions.AESdecrypt(nodeText.InnerText, tmpPwd, hashAlgorithm);
                }
                else
                {
                    docText = nodeText.InnerText;
                }

                return docText;
            }
            catch
            {
                throw new ArgumentNullException();
            }
        }

        /// <summary>
        /// Save an CTXT file which allready exist.
        /// </summary>
        /// <param name="sText">Insert in this parameter the text with RTF.</param>
        public void saveOpenedCtxt(string sText)
        {
            if (PassPhrase.Length > 1 & GetEncryption() != Encryption.Base64)
            {
                SavePassString = true;
            }
            else
            {
                SavePassString = false;
            }

            WriteFile(sText);
        }

        /// <summary>
        /// Get the encryption of the file 'filePath'.
        /// </summary>
        /// <returns>Returns the encryption as 'Encryption' which is used by a CTXT file.</returns>
        public Encryption GetEncryption()
        {
            XmlDocument xFile = new XmlDocument();
            xFile.Load(filePath);
            XmlNode nodeHead = xFile.GetElementsByTagName("head").Item(0);
            string encName = (nodeHead.Attributes.GetNamedItem("encryption").InnerText).ToLower();

            if (encName == "CryptotextEditoraes")
            {
                return Encryption.CryptotextEditorAES;
            }
            else if (encName == "timeaes")
            {
                return Encryption.TimeAES;
            }
            else if (encName == "base64" | encName == "64")
            {
                return Encryption.Base64;
            }
            else
            {
                throw new ArgumentNullException();
            }
        }

        /// <summary>
        /// Get the password of the file 'filePath'.
        /// </summary>
        /// <returns>Returns the password as a string which is used by a CTXT file.</returns>
        public static string GetPassphrase(string filePath)
        {
            string sReturn;
            XmlDocument xFile = new XmlDocument();
            xFile.Load(filePath);
            XmlNode nodeHead;
            string hashAlogithm = "SHA512";

            try
            {
                if (ctxtProperties.GetVersion(filePath) < ctxtProperties.verSupported)
                {
                    hashAlogithm = "MD5";
                }

                nodeHead = xFile.GetElementsByTagName("head").Item(0);
                sReturn = nodeHead.Attributes.GetNamedItem("passphrase").InnerText;
                sReturn = encryptions.AESdecrypt(sReturn, v21pass, hashAlogithm);

            }
            catch
            {
                sReturn = "";
            }

            return sReturn;
        }

        /// <summary>
        /// Write a file with the settings you choose.
        /// </summary>
        /// <param name="sText">The text the Rich-Text-Format.</param>
        public void WriteFile(string sText)
        {
            RichTextBox rtb = new RichTextBox();

            if (SaveWithRTF == true)
            {
                try
                {
                    rtb.Rtf = sText;
                    sText = rtb.Rtf;
                }
                catch
                {
                    SaveWithRTF = false;
                }
            }
            else
            {
                try
                {
                    rtb.Rtf = sText;
                    sText = rtb.Text;
                }
                catch { }
                finally
                {
                    SaveWithRTF = false;
                }
            }

            string tStamp = hashString.md5(DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString() + DateTime.Now.Day.ToString() + DateTime.Now.Hour.ToString() + DateTime.Now.Minute.ToString() + DateTime.Now.DayOfYear.ToString());
            XmlTextWriter XMLobj = new XmlTextWriter(filePath, UnicodeEncoding.UTF8);
            XMLobj.Formatting = Formatting.Indented;

            XMLobj.WriteStartDocument();

            XMLobj.WriteStartElement("ctxt");
            XMLobj.WriteAttributeString("version", verSupported.ToString());

            XMLobj.WriteStartElement("head");
            XMLobj.WriteAttributeString("encryption", encName.ToString());

            if (encName == Encryption.TimeAES)
            {
                XMLobj.WriteAttributeString("passphrase", encryptions.AESencrypt(tStamp, v21pass));
            }
            else if (SavePassString == true & encName == Encryption.CryptotextEditorAES)
            {
                XMLobj.WriteAttributeString("passphrase", encryptions.AESencrypt(PassPhrase, v21pass));
            }
            else if (SavePassString == false & encName != Encryption.Base64)
            {
                XMLobj.WriteAttributeString("passphrase", encryptions.AESencrypt("", v21pass));
            }

            XMLobj.WriteAttributeString("rtf", (SaveWithRTF.ToString()).ToLower());

            XMLobj.WriteEndElement();

            XMLobj.WriteStartElement("text");
            XMLobj.WriteValue(encText(sText, tStamp));
            XMLobj.WriteEndElement();

            XMLobj.WriteEndDocument();
            XMLobj.Close();
        }

        private string encText(string sText, string tStamp)
        {
            string retEncString;

            if (encName == Encryption.Base64)
            {
                retEncString = encryptions.ToBase64(sText);
            }
            else if (encName == Encryption.CryptotextEditorAES)
            {
                retEncString = encryptions.AESencrypt(sText, PassPhrase);
            }
            else if (encName == Encryption.TimeAES)
            {
                retEncString = encryptions.AESencrypt(sText, tStamp);
            }
            else
            {
                retEncString = sText;
            }

            return retEncString;
        }
    }
}
